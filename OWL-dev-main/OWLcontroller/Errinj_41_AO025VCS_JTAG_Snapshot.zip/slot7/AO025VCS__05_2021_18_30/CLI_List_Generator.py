import sys, os, time, traceback, pickle, zlib

mem_list = []
mem_buff_list = []
mem_file = "dump_mem.txt"
fp = open(mem_file, "r")
## Parse the dump_mem file to get list of all the memories
for line in fp:
        ## Loop till you reach the last line
        if not 'quit' in line:
                temp_list=[]
                ## Get parameters to create the list, format [name, type, start, end, length]
                start_address=int(line.split(' ')[2],16)
                length=int(line.split(' ')[3])
                end_address=start_address+length-1
                ## Create a list for that section
                temp_list.append(line.split(' ')[4].split('/')[2].split('.temp')[0])
                temp_list.append('')
                temp_list.append(start_address)
                temp_list.append(end_address)
                temp_list.append(length)
                ##print temp_list
                ## Append it to mem_list
                mem_list.append(temp_list)
        else:
                break

fp.close()
## Add DCCM to the list
mem_file = "dump_mem_dccm.txt"
fp = open(mem_file, "r")
for line in fp:
        ## Loop till you reach the last line
        if not 'quit' in line:
                temp_list=[]
                ## Get parameters to create the list, format [name, type, start, end, length]
                start_address=int(line.split(' ')[2],16)
                length=int(line.split(' ')[3])
                end_address=start_address+length-1
                ## Create a list for that section
                temp_list.append(line.split(' ')[4].split('/')[2].split('.temp')[0])
                temp_list.append('')
                temp_list.append(start_address)
                temp_list.append(end_address)
                temp_list.append(length)
                ##print temp_list
                ## Append it to mem_list
                mem_list.append(temp_list)
        else:
                break
fp.close()
##print mem_list

## We have compiled the list of memories now we will dump the memories.

for mem in mem_list:
        file_name="./Temp/"+mem[0]+".temp"
        fm=open(file_name,"rb")
        mem_string=fm.read()
        compressed_mem=zlib.compress(mem_string,9)
        mem_buff_list.append(compressed_mem)
        print " Dumping "+mem[0]
        fm.close()
        
dumpMap = {}
dumpMap ["MemoryList"] = mem_list
dumpMap ["MemoryBuffer"] = mem_buff_list

fp=open("CLI_Dump"+time.strftime("%Y%m%d_%H%M%S"),"wb")
pickle.dump(dumpMap,fp,2)
fp.close()
print "Dump Done"
        
        
        

